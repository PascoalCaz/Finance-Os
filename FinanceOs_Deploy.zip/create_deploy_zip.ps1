$exclude = @('node_modules', 'vendor', '.git', 'android', 'ios', 'FinanceOs_Deploy.zip', '.system_generated', '.gemini')
$items = Get-ChildItem -Path . | Where-Object { $exclude -notcontains $_.Name }
Write-Host "Compressing files..."
Compress-Archive -Path $items.FullName -DestinationPath .\FinanceOs_Deploy.zip -Force
Write-Host "Zip created successfully: FinanceOs_Deploy.zip"

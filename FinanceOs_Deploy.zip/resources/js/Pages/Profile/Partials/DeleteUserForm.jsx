import InputError from '@/Components/InputError';
import Modal from '@/Components/Modal';
import { useForm } from '@inertiajs/react';
import { useRef, useState } from 'react';
import { AlertTriangle, Trash2, XCircle } from 'lucide-react';

export default function DeleteUserForm({ className = '' }) {
    const [confirmingUserDeletion, setConfirmingUserDeletion] = useState(false);
    const passwordInput = useRef();

    const {
        data,
        setData,
        delete: destroy,
        processing,
        reset,
        errors,
        clearErrors,
    } = useForm({
        password: '',
    });

    const confirmUserDeletion = () => {
        setConfirmingUserDeletion(true);
    };

    const deleteUser = (e) => {
        e.preventDefault();

        destroy(route('profile.destroy'), {
            preserveScroll: true,
            onSuccess: () => closeModal(),
            onError: () => passwordInput.current.focus(),
            onFinish: () => reset(),
        });
    };

    const closeModal = () => {
        setConfirmingUserDeletion(false);
        clearErrors();
        reset();
    };

    return (
        <section className={className}>
            <div className="space-y-6">
                <p className="text-sm text-gray-500 leading-relaxed">
                    Ao eliminar a sua conta, todos os seus recursos e dados serão permanentemente apagados.
                    Antes de prosseguir, por favor descarregue qualquer dado que deseje manter.
                </p>

                <button
                    onClick={confirmUserDeletion}
                    className="px-8 py-4 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg shadow-red-100 flex items-center"
                >
                    <Trash2 size={16} className="mr-2" /> Eliminar Conta Recentemente
                </button>
            </div>

            <Modal show={confirmingUserDeletion} onClose={closeModal} title="Confirmar Eliminação">
                <form onSubmit={deleteUser} className="space-y-6">
                    <div className="flex items-center space-x-3 text-red-600 mb-4">
                        <AlertTriangle size={20} />
                        <h2 className="text-sm font-black uppercase tracking-tight">Tem a certeza que deseja apagar a conta?</h2>
                    </div>

                    <p className="text-xs text-gray-500 font-medium leading-relaxed">
                        Esta ação é irreversível. Por favor, insira a sua senha para confirmar que deseja eliminar permanentemente a sua conta.
                    </p>

                    <div className="mt-6">
                        <label className="block text-[11px] font-black text-gray-400 uppercase tracking-widest mb-3">Sua Senha</label>
                        <input
                            id="password"
                            type="password"
                            name="password"
                            ref={passwordInput}
                            value={data.password}
                            onChange={(e) => setData('password', e.target.value)}
                            className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-red-100 focus:border-red-400 transition-all font-mono"
                            placeholder="Insira a senha para confirmar"
                            required
                        />
                        <InputError message={errors.password} className="mt-2" />
                    </div>

                    <div className="mt-8 flex justify-end space-x-3">
                        <button
                            type="button"
                            onClick={closeModal}
                            className="px-6 py-3 bg-gray-100 text-gray-600 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-gray-200 transition-all"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            disabled={processing}
                            className="px-6 py-3 bg-red-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg active:scale-95 disabled:opacity-50 flex items-center"
                        >
                            {processing ? 'A Processar...' : 'Sim, Eliminar Conta'}
                        </button>
                    </div>
                </form>
            </Modal>
        </section>
    );
}

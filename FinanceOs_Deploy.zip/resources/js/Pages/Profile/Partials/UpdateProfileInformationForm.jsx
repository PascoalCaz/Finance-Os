import InputError from '@/Components/InputError';
import { Transition } from '@headlessui/react';
import { Link, useForm, usePage } from '@inertiajs/react';
import { CheckCircle, AlertCircle } from 'lucide-react';

export default function UpdateProfileInformation({
    mustVerifyEmail,
    status,
    className = '',
}) {
    const user = usePage().props.auth.user;

    const { data, setData, patch, errors, processing, recentlySuccessful } =
        useForm({
            name: user.name,
            email: user.email,
        });

    const submit = (e) => {
        e.preventDefault();
        patch(route('profile.update'));
    };

    return (
        <section className={className}>
            <form onSubmit={submit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <label className="block text-[11px] font-black text-gray-900 uppercase tracking-widest mb-3">Nome Completo</label>
                        <input
                            type="text"
                            value={data.name}
                            onChange={(e) => setData('name', e.target.value)}
                            className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-all"
                            required
                            autoComplete="name"
                        />
                        <InputError className="mt-2" message={errors.name} />
                    </div>

                    <div>
                        <label className="block text-[11px] font-black text-gray-900 uppercase tracking-widest mb-3">Endereço de Email</label>
                        <input
                            type="email"
                            value={data.email}
                            onChange={(e) => setData('email', e.target.value)}
                            className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-all"
                            required
                            autoComplete="username"
                        />
                        <InputError className="mt-2" message={errors.email} />
                    </div>
                </div>

                {mustVerifyEmail && user.email_verified_at === null && (
                    <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex items-start space-x-3">
                        <AlertCircle className="text-orange-500 mt-0.5" size={18} />
                        <div>
                            <p className="text-xs font-bold text-orange-800">Seu email não está verificado.</p>
                            <Link
                                href={route('verification.send')}
                                method="post"
                                as="button"
                                className="text-[10px] font-black uppercase text-orange-600 hover:text-orange-700 underline tracking-widest mt-1"
                            >
                                Clique aqui para reenviar o link de verificação.
                            </Link>

                            {status === 'verification-link-sent' && (
                                <div className="mt-2 text-[10px] font-black text-green-600 uppercase">
                                    Um novo link de verificação foi enviado.
                                </div>
                            )}
                        </div>
                    </div>
                )}

                <div className="flex items-center space-x-4 pt-4">
                    <button
                        type="submit"
                        disabled={processing}
                        className="px-10 py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-800 transition-all shadow-xl active:scale-95 disabled:opacity-50 flex items-center"
                    >
                        {processing ? 'A Guardar...' : 'Salvar Informações'}
                    </button>

                    <Transition
                        show={recentlySuccessful}
                        enter="transition ease-in-out"
                        enterFrom="opacity-0"
                        leave="transition ease-in-out"
                        leaveTo="opacity-0"
                    >
                        <div className="flex items-center space-x-2 text-green-600">
                            <CheckCircle size={18} />
                            <span className="text-xs font-bold uppercase tracking-tight">Atualizado com sucesso!</span>
                        </div>
                    </Transition>
                </div>
            </form>
        </section>
    );
}

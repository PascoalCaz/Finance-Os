import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import DeleteUserForm from './Partials/DeleteUserForm';
import UpdatePasswordForm from './Partials/UpdatePasswordForm';
import UpdateProfileInformationForm from './Partials/UpdateProfileInformationForm';
import { User, ShieldCheck, AlertTriangle } from 'lucide-react';

/**
 * =================================================================================
 * ARQUIVO: Profile/Edit.jsx (REDESIGN)
 * PROPÓSITO: Gerir a identidade e segurança do utilizador.
 * CONCEITOS ENSINADOS:
 * - Layout Composition: Organizar formulários complexos em seções visuais claras.
 * - Consistent Aesthetic: Usar Cards e ícones para elevar formulários padrões do Breeze.
 * =================================================================================
 */
export default function Edit({ mustVerifyEmail, status }) {
    return (
        <AuthenticatedLayout header="Definições de Perfil">
            <Head title="Meu Perfil" />

            <div className="space-y-10 pb-12">

                {/* SEÇÃO: INFORMAÇÕES BÁSICAS */}
                <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="p-8 border-b border-gray-50 flex items-center space-x-4 bg-[#fcfdfe]">
                        <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                            <User size={24} />
                        </div>
                        <div>
                            <h3 className="text-xl font-black text-gray-900 leading-none mb-1">Dados Pessoais</h3>
                            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">Atualize o seu nome e endereço de email</p>
                        </div>
                    </div>
                    <div className="p-8">
                        <UpdateProfileInformationForm
                            mustVerifyEmail={mustVerifyEmail}
                            status={status}
                            className="max-w-2xl"
                        />
                    </div>
                </div>

                {/* SEÇÃO: SEGURANÇA */}
                <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="p-8 border-b border-gray-50 flex items-center space-x-4 bg-[#fcfdfe]">
                            <ShieldCheck size={24} />
                        <div>
                            <h3 className="text-xl font-black text-gray-900 leading-none mb-1">Segurança da Conta</h3>
                            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">Garanta que a sua conta está protegida com uma senha forte</p>
                        </div>
                    </div>
                    <div className="p-8">
                        <UpdatePasswordForm className="max-w-2xl" />
                    </div>
                </div>

                {/* SEÇÃO: ZONA DE PERIGO */}
                <div className="bg-white rounded-3xl border border-red-100 shadow-sm overflow-hidden">
                    <div className="p-8 border-b border-red-50 flex items-center space-x-4 bg-red-50/30">
                        <div className="p-3 bg-red-100 text-red-600 rounded-2xl">
                            <AlertTriangle size={24} />
                        </div>
                        <div>
                            <h3 className="text-xl font-black text-red-900 leading-none mb-1">Zona Crítica</h3>
                            <p className="text-[11px] font-bold text-red-400 uppercase tracking-widest">Ações permanentes e irreversíveis</p>
                        </div>
                    </div>
                    <div className="p-8">
                        <DeleteUserForm className="max-w-2xl" />
                    </div>
                </div>

            </div>
        </AuthenticatedLayout>
    );
}
